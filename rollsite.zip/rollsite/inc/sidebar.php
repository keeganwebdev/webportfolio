

<div class="well">
        <ul class="nav nav-stacked" id="sidebar">
            <li><a href="../pages/declareactivity.php">Declare Activity</a></li>
          
            <li><a href="../pages/classrolls.php">Mark Roll</a></li>
  <li><a href="../pages/editclassrolls.php">Edit Roll</a></li>
  <li><a href="../pages/attendance_rolls.php">View Attendance</a></li>
        </ul>
  </div>
