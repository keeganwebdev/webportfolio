<?php

include "../inc/database.php";
include "../inc/header.php";
include "../inc/admincheck.php";
?>
<div class="flex-container">
   <div class="flex-item"><a href="../adminpages/enrollstudent.php" class="fill-div">Enroll Student</a></div>
  <div class="flex-item"><a href="../adminpages/enroll_list.php" class="fill-div">Cancel Enrollment</a></div>
</div>