<?php
include "../inc/database.php";
include "../inc/header.php";
include "../inc/admincheck.php";
?>
<div class="flex-container">
  <div class="flex-item"><a href="../adminpages/insert_admin.php" class="fill-div">Insert Info</a></div>
   <div class="flex-item"><a href="../adminpages/users.php" class="fill-div">Users</a></div>
   <div class="flex-item"><a href="../adminpages/enrollmentpage.php" class="fill-div">Enrollment</a></div>
  <div class="flex-item"><a href="../adminpages/edit_admin.php" class="fill-div">Edit Info</a></div>
  <div class="flex-item"><a href="../adminpages/orderbyteacher.php" class="fill-div">View Courses </a></div>
  <div class="flex-item"><a href="../adminpages/studentmenu.php" class="fill-div">Attendance</a></div>
</div>
