<?php
include "../inc/database.php";
include "../inc/header.php";
include "../inc/admincheck.php";
?>
<div class="flex-container">
  <div class="flex-item"><a href="../adminpages/editclasslist.php" class="fill-div">Edit Courses</a></div>
  <div class="flex-item"><a href="../adminpages/edit_teacherlist.php" class="fill-div">Edit Teachers</a></div>
  <div class="flex-item"><a href="../adminpages/edit_studentlist.php" class="fill-div">Edit Students</a></div>
</div>
