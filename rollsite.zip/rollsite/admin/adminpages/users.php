
<?php
include "../inc/database.php";
include "../inc/header.php";
include "../inc/admincheck.php";
?>
<div class="flex-container">
    <div class="flex-item"><a href="../adminpages/registry.php" class="fill-div">Add Users</a></div>
  <div class="flex-item"><a href="../adminpages/editaccounts.php" class="fill-div">Edit Users</a></div>
</div>