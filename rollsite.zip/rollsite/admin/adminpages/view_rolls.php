<?php
include "../inc/header.php";
include "../inc/database.php";
include "../inc/admincheck.php";
?>
<div class="flex-item"><a href="../adminpages/insert_admin.php" class="fill-div">View By Teacher</a></div>
<div class="flex-item"><a href="../adminpages/edit_admin.php" class="fill-div">View By Date </a></div>
<div class="flex-item"><a href="../adminpages/view_courses.php" class="fill-div">View By Class Location</a></div>
