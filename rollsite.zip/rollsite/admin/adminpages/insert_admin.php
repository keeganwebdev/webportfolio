<?php
include "../inc/database.php";
include "../inc/header.php";
include "../inc/admincheck.php";
?>
<div class="flex-container">
  <div class="flex-item"><a href="../adminpages/insert_course.php" class="fill-div">Insert Course</a></div>
  <div class="flex-item"><a href="../adminpages/insert_teacher.php" class="fill-div">Insert Teacher</a></div>
  <div class="flex-item"><a href="../adminpages/insert_student.php" class="fill-div">Insert Student</a></div>
</div>
