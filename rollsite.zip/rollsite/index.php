<?php 
echo  "<script>window.open('pages/login.php','_self')</script>";
?>
