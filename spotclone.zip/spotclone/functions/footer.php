				</div>


			</div>

		</div>

		<?php include("nowPlayingBar.php"); ?>

	</div>

</body>

</html>