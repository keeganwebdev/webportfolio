<?php
include("functions/includedfiles.php");
?>


<script>openPage("browse.php");</script>
